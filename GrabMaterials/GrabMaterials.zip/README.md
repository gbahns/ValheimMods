# MojoRyzen's Grab Materials Mod

Created on January 30 2025.

The idea is to be able to quickly pull materials from nearby chests into your inventory without having to manually click on each chest.  The concept is similar to mods that let you craft or build directly from containers, but for things that you're not building in your base.  The typical example is workbench and portal when exploring - you're constantly having to grab 10 wood, 20 finewood, 10 greydwarf eyes, and 2 surtling cores.  This mod removes that tedium.

<h3>Currently there are three ways to use the mod:</h3>

1. "/grab" in the chat window
2. 3 configurable key shortkey keys
3. configurable game controller button

See wiki for more details.
[text](https://thunderstore.io/c/valheim/p/MojoRyzen/GrabMaterials/wiki/3012-mojoryzens-grab-materials-mod/)
